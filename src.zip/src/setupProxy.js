const proxy = require("http-proxy-middleware");

module.exports = function (app) {
  app.use(
    proxy("/dev/put", {
      target: "https://hpd3sflgm9.execute-api.us-east-1.amazonaws.com/",
      secure: false,
      changeOrigin: true,
    })
  );
};
